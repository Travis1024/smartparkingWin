package com.graduation.server.mapper;

import com.graduation.server.pojo.Pricelist;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.graduation.server.pojo.Pricelist;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author travis-wei
 * @since 2022-01-23
 */
public interface PricelistMapper extends BaseMapper<Pricelist> {

}
