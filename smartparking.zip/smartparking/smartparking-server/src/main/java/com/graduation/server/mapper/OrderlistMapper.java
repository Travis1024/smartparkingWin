package com.graduation.server.mapper;

import com.graduation.server.pojo.Orderlist;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.graduation.server.pojo.Orderlist;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author travis-wei
 * @since 2022-01-23
 */
public interface OrderlistMapper extends BaseMapper<Orderlist> {

}
