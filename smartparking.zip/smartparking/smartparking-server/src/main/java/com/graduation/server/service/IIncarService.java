package com.graduation.server.service;

import com.graduation.server.pojo.Incar;
import com.baomidou.mybatisplus.extension.service.IService;
import com.graduation.server.pojo.Incar;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author travis-wei
 * @since 2022-01-23
 */
public interface IIncarService extends IService<Incar> {

}
